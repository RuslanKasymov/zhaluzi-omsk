<?php
/**
* @package RSForm! Pro
* @copyright (C) 2007-2014 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

class TableRSForm_Forms extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $FormId = null;
	
	var $FormName = '';
	var $FormLayout = '';
	var $FormLayoutName = 'responsive';
	var $FormLayoutAutogenerate = 1;
	var $CSS = '';
	var $JS = '';
	var $FormTitle = '';
	var $ShowFormTitle = 1;
	var $Lang = '';
	var $Keepdata = 1;
	var $ReturnUrl = '';
	var $ShowThankyou = 1;
	var $Thankyou = '';
	var $ShowContinue = 1;
	var $UserEmailText = '';
	var $UserEmailTo = '';
	var $UserEmailCC = '';
	var $UserEmailBCC = '';
	var $UserEmailFrom = '';
	var $UserEmailReplyTo = '';
	var $UserEmailFromName = '';
	var $UserEmailSubject = '';
	var $UserEmailMode = 1;
	var $UserEmailAttach = 0;
	var $UserEmailAttachFile = '';
	var $AdminEmailText = '';
	var $AdminEmailTo = '';
	var $AdminEmailCC = '';
	var $AdminEmailBCC = '';
	var $AdminEmailFrom = '';
	var $AdminEmailReplyTo = '';
	var $AdminEmailFromName = '';
	var $AdminEmailSubject = '';
	var $AdminEmailMode = 1;
	var $ScriptProcess = '';
	var $ScriptProcess2 = '';
	var $ScriptDisplay = '';
	var $UserEmailScript = '';
	var $AdminEmailScript = '';
	var $AdditionalEmailsScript = '';
	var $MetaTitle = '';
	var $MetaDesc = '';
	var $MetaKeywords = '';
	var $Required = '(*)';
	var $ErrorMessage = '<p class="formRed">Please complete all required fields!</p>';
	var $MultipleSeparator = '\n';
	var $TextareaNewLines = 1;
	var $CSSClass = '';
	var $CSSId = 'userForm';
	var $CSSName = '';
	var $CSSAction = '';
	var $CSSAdditionalAttributes = '';
	var $AjaxValidation = 0;
	var $ThemeParams = '';
	var $Backendmenu = '';
	var $ConfirmSubmission = 0;
	var $Access = '';
	
	var $Published = 1;
		
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(& $db)
	{
		parent::__construct('#__rsform_forms', 'FormId', $db);
	}
}